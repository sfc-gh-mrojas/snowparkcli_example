from setuptools import find_packages, setup

setup(
    name='python_package',  # Required: the name of your package
    version='0.1.0',      # Required: the initial release version
    packages=find_packages(),  # Required: automatically find packages in the directory
)
